import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
print(stopwords.words('french'))

stop_words = set(stopwords.words('french'))

stop_words_final = []
stop_words_final.append(',')
stop_words_final.append("’")
stop_words_final.append('.')
stop_words_final.append('✅')
stop_words_final.append('(')
stop_words_final.append(')')
stop_words_final.append(':')
stop_words_final.append('...')
stop_words_final.append('|')
stop_words_final.append("l'")
stop_words_final.append("d'")
stop_words_final.append('type')
stop_words_final.append("j'ai")
stop_words_final.append('capable')
stop_words_final.append('esprit')
stop_words_final.append('capacité')
stop_words_final.append('fait')
stop_words_final.append('capacite')
stop_words_final.append('aussi')
stop_words_final.append('ainsi')
stop_words_final.append('compétences')
stop_words_final.append('compétence')
stop_words_final.append('problèmes')
stop_words_final.append('problème')

stop_words_final = stop_words_final + stopwords.words('french')
stop_words_final = set(stop_words_final)

phrase = """
Traitement de texte (type Word...), Tableur (type Excel...), Présentation (type Powerpoint...), Base de données (type Access...) | Langage(s) de programmation : sql server | Logiciel(s) : visuel basic | Système(s) d'exploitation : Microsoft Windows 95/98/me, Microsoft Windows 2000 | Permis : B"""
word_tokens = word_tokenize(phrase)

phrase_filtree = [w for w in word_tokens if not w.lower() in stop_words_final]

print(phrase)
print("***************************")
print(phrase_filtree)


