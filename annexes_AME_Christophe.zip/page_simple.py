from requests import get
from scrapy import Selector
import re


def catch_URL(URL):
    url = URL
    response = get(url)
    source = None

    if response.status_code == 200:
        source = response.text
        return source


def catch_data(source):
    if source:
        # Si le contenu source existe

        selector = Selector(text=source)
        contenu = selector.css("body")
        #Ou alors contenu = selector.xpath("//")

        print("CONTENU ")
        print("_________________________________________________________________________________")
        contenu_extrait = contenu.css("*::text").extract()

        return contenu_extrait


#url_emploi = "https://www.emploi.ma/recherche-jobs-maroc"
url_emploi = input("URL de la page : ")
# Par exemple "https://www.emploi.ma/offre-emploi-maroc/consultant-securite-informatique-5948742"

source = catch_URL(url_emploi)
data = catch_data(source)

for e in data :
    print(e)
