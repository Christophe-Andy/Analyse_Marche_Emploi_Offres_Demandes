import nltk
#nltk.download('treebank')
#nltk.download('maxent_ne_chunker')
#nltk.download('words')
from nltk.corpus import treebank_chunk
from nltk.chunk import ne_chunk

phrase = "Ali travaille tous les Dimanches chez Sephora"
print(treebank_chunk.tagged_sents()[0])
print(ne_chunk(treebank_chunk.tagged_sents()[0]))