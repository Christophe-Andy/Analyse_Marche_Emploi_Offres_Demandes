import pandas as pd
import time
from pandas import notnull

'''datas = [ { "region":"Casa", "compagny":"Attijari", "descriptif":"Nous recrutons" },
      { "region":"Rabat", "compagny":"BMCE", "descriptif":"Nous recrutons" },]

datasEmploi = pandas.DataFrame(datas)

datasEmploi.loc[2] = ["Settat"] + ["OCP"] + ["Nous recrutons"]

print(datasEmploi.iloc[0])
print("________________________________")'''


#base_data = pd.DataFrame(base)
#print(base_data)'